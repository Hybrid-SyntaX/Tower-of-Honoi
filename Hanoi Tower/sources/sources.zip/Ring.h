#pragma once
#include "base3dobject.h"
#include "Texture.h"
#include "headers.h"
enum State{Attached,Detached,Rejected};

class Ring :
	public Base3DObject
{

public:
	
	Ring(void);
	Ring::Ring(const Ring& ring);


	~Ring(void);
	void Render(void);
	void RenderAt(float X,float Y,float Z);
	Ring * Clone();
	void Log();


	Ring& operator=(const Ring & ring);

	void MoveUp();
	void MoveDown();
	void MoveLeft();
	void MoveRight();

	short Value;
	float Offset;

	


	
	State state;
	
	int * Tag;

};

