#pragma once
#include "headers.h"
#include "Texture.h"

class _Position
{
public :

		float X;
		float Y;
		float Z;
		float Offset;
		float Angle;

		void MoveTo(float X,float Y,float Z);
		void RotateAround(float Angle,char Direction);
		void Set(float X,float Y,float Z);
};

class _Size
{
public :
		float Width;
		float Height;
		float Depth;

		void ScaleBy(float size)
		{
			Width+=size;
			Height+=size;
			Depth+=size;
			glScalef(Width,Height,Depth);
		}
};
class _Color
{
public :
	 
		 GLubyte Red;
		 GLubyte Green;
		 GLubyte Blue;
		 GLubyte Alpha;

		 _Color()
		 {
			cout<<"Color @ " <<this<<" is created"<<endl;
		 }

		 _Color(const _Color& color)
		 {
			 this->Alpha=color.Alpha;
			 this->Blue=color.Blue;
			 this->Green=color.Green;
			 this->Red=color.Red;
		 }

		 _Color& operator=(const _Color & color) {
			  if (this == &color)
				return *this;  
		 }

		void set(GLubyte Red,GLubyte Green,GLubyte Blue)
		{
			this->set(Red,Green,Blue,0);
		}
		void set(GLubyte Red,GLubyte Green,GLubyte Blue,GLubyte Alpha)
		{
			this->Red=Red;
			this->Green=Green;
			this->Blue=Blue;
			this->Alpha=Alpha;

			
		}
		void Render()
		{
			glColor4ub(this->Red,this->Green,this->Blue,this->Alpha);
			
		}
};
class Base3DObject 
{

	
	public:
		~Base3DObject(void);
		Base3DObject(void);


		auto_ptr<_Position>  Position;
		auto_ptr<_Size> Size;
		_Color   Color;
		_Texture Texture;

	
};

