#include "headers.h"
#include "classes.h"
#include "prototypes.h"

extern auto_ptr<Ring> ActiveRing;

void RenderScene(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glColor3ub(255,255,255);
	//RenderString(0, 90, GLUT_BITMAP_TIMES_ROMAN_24,message);

	//Texture.End
	if(ActiveRing.get()!=NULL)
	{
		ActiveRing->Render();
	}

	RenderTowers();

	

	glutSwapBuffers();
}