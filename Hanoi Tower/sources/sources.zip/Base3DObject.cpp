#include "Base3DObject.h"


Base3DObject::Base3DObject(void)
{

	//Texture=auto_ptr<_Texture>(new _Texture);
	//Color=auto_ptr<_Color>(new _Color());
	Position=auto_ptr<_Position>(new _Position());
	Size=auto_ptr<_Size>(new _Size());

}


Base3DObject::~Base3DObject(void)
{
	

//	 this->Texture.release();
//	 this->Color.release();
	 this->Position.release();
	 this->Size.release();

	 
}

void _Position::MoveTo(float X,float Y,float Z)
{
			this->Set(X,Y,Z);

			glTranslatef(this->X,this->Y,this->Z);
}
void _Position::Set(float X,float Y,float Z)
{
			this->X=X;
			this->Y=Y;
			this->Z=Z;
}
void _Position::RotateAround(float Angle,char Direction)
{
	this->Angle=Angle;

	switch(Direction)
	{
		case 'x':glRotatef(Angle,1.0,0.0,0.0);
		break;
		case 'y':glRotatef(Angle,0.0,1.0,0.0);
		break;
		case 'z':glRotatef(Angle,0.0,0.0,1.0);
		break;
	}
			
}